package com.citibank.main;

public class MethodReferenceMain {

	public static void main(String[] args) {
		Thread thread = new Thread(() -> System.out.println("We are in thread"));
		thread.start();

		System.out.println("-".repeat(50));
		Thread thread2 = new Thread(() -> printMessage());
		thread2.start();

		Thread thread3 = new Thread(MethodReferenceMain::printMessage); // same as () -> printMessage()
		thread3.start();

	}

	public static void printMessage() {
		System.out.println("Hello from printMessage()");
	}
}
