package com.citibank.main;

public interface StringLengthLambda {
	public int getLength(String str);
}
