package com.citibank.util.internal;

//Only for Calculator class. Do not use this class directly.
public class CalculatorHelper {
	public int add(int i, int j) {
		return i + j;
	}
}
