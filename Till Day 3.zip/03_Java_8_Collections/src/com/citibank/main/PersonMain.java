package com.citibank.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

import com.citibank.pojo.Person;

public class PersonMain {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		printAll(people);

		System.out.println("-".repeat(50));
		System.out.println("Sort by last name");
		// Without using lambda expression (no lambda expression)
		// Step 1 :: Sort the list by last name
		Collections.sort(people, new Comparator<Person>() {
			@Override
			public int compare(Person p1, Person p2) {
				return p1.getLastName().compareTo(p2.getLastName());
			}
		});

		// Step 2 :: Call Print all method to print sorted collection
		printAll(people);

		System.out.println("-".repeat(50));
		System.out.println("Last name beginning with G");
		// Step 3 :: Create new method that prints all people that have
		// last name beginning with G
		printConditionally(people, new Predicate<Person>() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().startsWith("G"))
					return true;
				return false;
			}
		});

		System.out.println("-".repeat(50));
		System.out.println("Last name ending with L");
		// Step 4 :: Create new method that prints all people that have
		// last name ending with L(small case l)
		printConditionally(people, new Predicate<Person>() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().endsWith("l"))
					return true;
				return false;
			}
		});

	}

	public static void printConditionally(List<Person> people, Predicate<Person> predicate) {
		for (Person person : people) {
			if (predicate.test(person)) {
				System.out.println(person);
			}
		}
	}

	private static void printAll(List<Person> people) {
		for (Person person : people) {
			System.out.println(person);
		}
	}
}

interface Condition {
	public boolean test(Person person);
}
