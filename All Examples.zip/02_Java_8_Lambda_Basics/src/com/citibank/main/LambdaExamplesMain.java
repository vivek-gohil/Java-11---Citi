package com.citibank.main;

import java.util.Scanner;

public class LambdaExamplesMain {
	public static void main(String[] args) {
		// StringLengthLambda stringLengthLambda = (str) -> str.length();

		// System.out.println("String length is :: " +
		// stringLengthLambda.getLength("Hello World"));

		// StringLengthLambda stringLengthLambda = (String s) -> s.length();
		// StringLengthLambda stringLengthLambda = (s) -> s.length();
		// StringLengthLambda stringLengthLambda = s -> s.length();

		System.out.println("Enter String to find the length");
		Scanner scanner = new Scanner(System.in);
		String text = scanner.nextLine();
		print(s -> s.length(), text);

		calcualtionLambda((num1, num2) -> num1 + num2);
		calcualtionLambda((num1, num2) -> num1 - num2);
		calcualtionLambda((num1, num2) -> num1 * num2);
		calcualtionLambda((num1, num2) -> num1 / num2);

	}

	public static void print(StringLengthLambda stringLengthLambda, String text) {
		System.out.println("Length is :: ");
		System.out.println(stringLengthLambda.getLength(text));
	}

	public static void calcualtionLambda(ArithmaticOperation arithmaticOperation) {
		System.out.println("Result is " + arithmaticOperation.calculateResult(10, 2));
	}

	interface ArithmaticOperation {
		double calculateResult(double num1, double num2);
	}
}
