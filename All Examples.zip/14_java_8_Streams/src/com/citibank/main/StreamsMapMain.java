package com.citibank.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.citibank.pojo.Person;

public class StreamsMapMain {
	public static void main(String[] args) {
		List<String> alphabets = Arrays.asList("a", "b", "c", "d", "e");

		// Convert this alphabets to upper case and add it into a new list

		// Java 7 approach
		List<String> alphabetsUpper = new ArrayList<String>();
		for (String string : alphabets) {
			alphabetsUpper.add(string.toUpperCase());
		}

		for (String string : alphabetsUpper) {
			System.out.println(string);
		}

		// Java 8 using Streams
		alphabets.stream().map(new Function<String, String>() {
			@Override
			public String apply(String t) {
				return t.toUpperCase();
			}
		}).forEach(new Consumer<String>() {
			@Override
			public void accept(String t) {
				System.out.println(t);
			}
		});

		System.out.println("Using Java 8 Stream + Lambda");
		alphabets.stream().map(t -> t.toUpperCase()).forEach(t -> System.out.println(t));
		System.out.println("Using Method ref");
		alphabets.stream().map(t -> t.toUpperCase()).forEach(System.out::println);
		System.out.println();

		alphabetsUpper = alphabets.stream().map(t -> t.toUpperCase()).collect(Collectors.toList());

		alphabetsUpper.forEach(System.out::println);

		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		// Print All the first name in upper case and store in new list

		List<String> firstNameList = people.stream().map(p -> p.getFirstName().toUpperCase())
				.collect(Collectors.toList());
		firstNameList.forEach(System.out::println);

	}
}
