package com.citibank.main;

public class LambdaExamples {
	public static void main(String[] args) {
		// StringLength stringLength = (String text) -> text.length();
		// StringLength stringLength = (text) -> text.length();
		StringLength stringLength = t -> t.length();

		// print(stringLength);
		print("Hello", t -> t.length());

		calculate((n1, n2) -> n1 + n2, 10, 20);
		calculate((n1, n2) -> n1 - n2, 100, 20);
		calculate((n1, n2) -> n1 * n2, 10, 2);
		calculate((n1, n2) -> n1 / n2, 10, 2);
	}

	public static void print(String text, StringLength stringLength) {
		System.out.println("String length :: " + stringLength.getLength(text));
	}

	public static void calculate(ArithmaticOperations arth, double n1, double n2) {
		System.out.println("Result is  " + arth.calculateResult(n1, n2));
	}

	@FunctionalInterface
	interface StringLength {
		int getLength(String text);
	}

	interface ArithmaticOperations {
		double calculateResult(double n1, double n2);
	}
}
