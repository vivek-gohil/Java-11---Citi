package com.citibank.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.citibank.pojo.Person;

public class PersonMain_Lambda {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		printConditionally(people, p -> true, p -> System.out.println(p));

		System.out.println("-".repeat(50));
		System.out.println("Sort by last name");

		Collections.sort(people, (p1, p2) -> p1.getLastName().compareTo(p2.getLastName()));
		printConditionally(people, p -> true, p -> System.out.println(p));

		System.out.println("-".repeat(50));
		System.out.println("Last name beginning with G");
		printConditionally(people, p -> p.getLastName().startsWith("G"),
				p -> System.out.println(p.getFirstName() + " " + p.getLastName()));

		System.out.println("-".repeat(50));
		System.out.println("Last name ending with L");
		//printConditionally(people, p -> p.getLastName().endsWith("l"), p -> System.out.println(p));

		printConditionally(people, p -> p.getLastName().endsWith("l"), System.out::println);

	}

	public static void printConditionally(List<Person> people, Predicate<Person> predicate, Consumer<Person> consumer) {
		for (Person person : people) {
			if (predicate.test(person)) {
				consumer.accept(person);
			}
		}
	}

}
