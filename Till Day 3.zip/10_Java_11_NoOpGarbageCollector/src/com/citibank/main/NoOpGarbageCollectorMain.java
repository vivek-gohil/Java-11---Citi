package com.citibank.main;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.ArrayList;
import java.util.Scanner;

public class NoOpGarbageCollectorMain {
	public static ArrayList<String> list = new ArrayList<String>();

	public static void main(String[] args) {
		System.out.println("Starting");
		while (true) {
			for (int i = 0; i < 100000; i++) {
				list.add("" + i);
			}
			if (calculatePercentageMemoryUsed() > 85) {
				System.out.println("Over 85% memory unitilization");
				System.out.println("Do you want to clear memory y-n?");
				Scanner scanner = new Scanner(System.in);
				String input = scanner.next();
				if (input.equalsIgnoreCase("y")) {
					list.clear();
					System.out.println("Memory Cleared");
				}
			}
		}
	}

	private static long calculatePercentageMemoryUsed() {
		MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
		MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
		long maxMemory = heapUsage.getMax() / (1024 * 1024);
		long usedMemory = heapUsage.getUsed() / (1024 * 1024);
		long percentageUsed = (long) (100.0 * ((1.0 * usedMemory) / (1.0 * maxMemory)));
		System.out.println(
				"Used :: " + usedMemory + " Max :: " + maxMemory + " Percentage Used ::" + percentageUsed + "%");
		return percentageUsed;
	}

}
