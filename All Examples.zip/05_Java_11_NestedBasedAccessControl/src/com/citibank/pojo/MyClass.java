package com.citibank.pojo;

public class MyClass {
	private String message = "This is sample text message";

	public class NewClass {
		public void printMessage() {
			System.out.println(message);
		}
	}
}

//After compile MyClass.java , Java compile create something similer to this
//public class MyClass {
//	private String name = "This is sample text message";
//	
//	String access$000() {
//		return name;
//	}
//}
//
//public class MyClass$NewClass {
//	final MyClass obj;
//	public void printMessage() {
//		System.out.println(obj.access$000())
//	}
//}
