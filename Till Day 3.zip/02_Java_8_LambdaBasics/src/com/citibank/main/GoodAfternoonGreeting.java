package com.citibank.main;

public class GoodAfternoonGreeting implements Greeting {
	public void performGreeting() {
		System.out.println("Good Afternoon");
	}
}
