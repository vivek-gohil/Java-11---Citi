package com.citibank.main;

@FunctionalInterface
public interface Greeting {
	public void perfom();
	// public void show();
}
