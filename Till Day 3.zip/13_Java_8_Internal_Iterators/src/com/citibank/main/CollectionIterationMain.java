package com.citibank.main;

import java.util.Arrays;
import java.util.List;

import com.citibank.pojo.Person;

public class CollectionIterationMain {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		System.out.println("External Iterator");
		System.out.println("1.For in loop");
		for (Person person : people) {
			System.out.println(person);
		}

		System.out.println("Internal Iterator");
		people.forEach(p -> System.out.println(p.getFirstName()));

		System.out.println("Using Method Referencing ");
		people.forEach(System.out::println);

	}

}
