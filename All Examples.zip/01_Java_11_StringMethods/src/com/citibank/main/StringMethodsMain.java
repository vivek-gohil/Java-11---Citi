package com.citibank.main;

import java.util.List;
import java.util.stream.Collectors;

public class StringMethodsMain {
	public static void main(String[] args) {
		System.out.println("1. isBlank");
		String name = "Citi bank NA";
		System.out.println("Checking if value of name variable is blank :: " + name.isBlank());
		name = " ";
		System.out.println("Checking if value of name variable is blank :: " + name.isBlank());

		System.out.println("isBlank vs isEmpty");
		name = "Citi bank NA";
		System.out.println("Checking if value of variable is empty :: " + name.isEmpty());
		name = " ";
		System.out.println("Checking if value of variable is empty :: " + name.isEmpty());

		name = null;
		// System.out.println("Checking if value of variable is empty :: " +
		// name.isEmpty());
		// System.out.println("Checking if value of variable is empty :: " +
		// name.isBlank());

		System.out.println();
		System.out.println("2. lines");
		String str = "Vivek\nAnand\nBhargavi\nHimanshu";
		System.out.println(str);
		List<String> nameList = str.lines().collect(Collectors.toList());
		System.out.println(nameList);

		System.out.println();
		System.out.println("3. strip");
		str = " Citi bank NA ";
		System.out.println("Value of String before calling strip");
		System.out.print("start");
		System.out.print(str);
		System.out.print("end");

		System.out.println();
		System.out.println("Value of String afer calling strip");
		System.out.print("start");
		System.out.print(str.strip());
		System.out.print("end");

		System.out.println("Value of String afer calling stripLeading");
		System.out.print("start");
		System.out.print(str.stripLeading());
		System.out.print("end");
		
		System.out.println("Value of String afer calling stripTrailing");
		System.out.print("start");
		System.out.print(str.stripTrailing());
		System.out.print("end");
		
		System.out.println();
		System.out.println("strip vs trim");

		str = "Citi bank NA\u205F";
		char c = '\u205F';
		System.out.println(c);

		System.out.println("Using strip " + str.strip());
		System.out.println("Using trim " + str.trim());

		//strip() :: is Unicode-aware 
		//trim() :: removes only space (<0020)
		
		System.out.println("5. repeat");
		str = " Citi bank NA ";
		System.out.println(str.repeat(5));
		
	}
}
