package com.citibank.main;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Date;

public class ReadingWritingStringMain {
	public static void main(String[] args) {
		try {
			Date date = new Date();
			Files.writeString(Paths.get("./data.txt"), date.toString(), StandardCharsets.UTF_8,
					StandardOpenOption.WRITE);
			System.out.println(date.toString());
			System.out.println("Check your file");

			String data = Files.readString(Paths.get("./data.txt"));
			System.out.println(data);

		} catch (IOException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		}
	}
}
