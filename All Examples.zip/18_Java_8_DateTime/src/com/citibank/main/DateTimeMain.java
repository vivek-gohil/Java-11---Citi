package com.citibank.main;

import java.time.LocalDate;

public class DateTimeMain {
	public static void main(String[] args) {
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);

		LocalDate customDate = LocalDate.of(2019, 01, 18);
		System.out.println(customDate);

		customDate = customDate.plusDays(5);
		System.out.println(customDate);

		customDate = customDate.minusDays(2);
		System.out.println(customDate);

	}
}
