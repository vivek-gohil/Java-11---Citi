package com.citibank.main;

import java.util.List;
import java.util.stream.Collectors;

public class StringMethodsMain {
	public static void main(String[] args) {
		System.out.println("1. isBlank");
		String name = "Citi bank";
		System.out.println("Checking if value of name is blank :: " + name.isBlank());
		name = " ";
		System.out.println("Checking if value of name is blank :: " + name.isBlank());

		System.out.println("-".repeat(50));

		System.out.println("isBlank vs isEmpty");
		name = "Citi bank";
		System.out.println("Checking if value of name is empty :: " + name.isEmpty());
		name = " ";
		System.out.println("Checking if value of name is empty :: " + name.isEmpty());

		System.out.println("-".repeat(50));
		System.out.println("2. lines");
		String str = "Vivek\nVishnu\nShobha\nAshutosh\nKomal";
		System.out.println(str);
		// <String> nameList = str.lines().collect(Collectors.toList());
		// System.out.println(nameList);

		System.out.println("-".repeat(50));
		System.out.println("3. strip");
		str = " Citi bank\u205F";
		System.out.println("Value of string before calling strip");
		System.out.print("start");
		System.out.print(str);
		System.out.print("end");

		System.out.println("-".repeat(50));
		System.out.println("Value of string after calling strip");
		System.out.print("start");
		System.out.print(str.strip());
		System.out.print("end");
		System.out.println("-".repeat(50));
		System.out.println(" strip vs trim");

		System.out.println();
		System.out.println("Value of string after calling trim");
		System.out.print("start");
		System.out.print(str.trim());
		System.out.print("end");
		// Returns a string whose value is this string, with all leadingand trailing
		// space removed,
		// where space is definedas any character whose codepoint is less than or equal
		// to 'U+0020' (the space character).
		// strip :: is Unicode aware

		System.out.println("-".repeat(50));
		System.out.println("5. stripTrailing");
		str = " Citi bank ";
		System.out.println("Value of string before calling stripTrailing");
		System.out.print("start");
		System.out.print(str.stripTrailing());
		System.out.print("end");

		System.out.println("-".repeat(50));
		System.out.println("6. stripLeading");
		str = " Citi bank ";
		System.out.println("Value of string before calling stripLeading");
		System.out.print("start");
		System.out.print(str.stripLeading());
		System.out.print("end");

		System.out.println("-".repeat(50));

		System.out.println("7. repeat");
		str = " Java 11 ";
		System.out.println(str.repeat(5));
	}
}
