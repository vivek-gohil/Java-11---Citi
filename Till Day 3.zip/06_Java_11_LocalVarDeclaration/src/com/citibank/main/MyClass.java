package com.citibank.main;

public class MyClass {
	public static void main(String[] args) {
		StringLength stringLength = (var text) -> text.toString().length();

		System.out.println("Length :: " + stringLength.getLength("Hello"));
		// System.out.println("Length :: " + stringLength.getLength(1234));
	}
}

interface StringLength {
	int getLength(String text);
}
