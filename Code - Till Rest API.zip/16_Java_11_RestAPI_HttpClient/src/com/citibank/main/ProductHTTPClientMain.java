package com.citibank.main;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest; // Java 11
import java.net.http.HttpResponse; // Java 11
import java.net.http.HttpResponse.BodyHandlers;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import com.citibank.main.pojo.Product;
import com.citibank.util.JSONUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;

public class ProductHTTPClientMain {

	private static final HttpClient client = HttpClient.newBuilder().version(Version.HTTP_2).build();
	private static final String serviceURL = "http://localhost:8080/product/controller/";

	public static void main(String[] args) {
		try {
			getAllProducts();
			//getProductDetailsById();
			// addProduct();
			// updateProduct();
			//deleteProduct();
		} catch (JsonProcessingException | InterruptedException | ExecutionException e) {
			System.out.println("Exception");
			System.out.println(e.getMessage());
		}
	}

	// send request to delete the product by its productId
	public static void deleteProduct() throws ExecutionException, InterruptedException, IOException {
		HttpRequest request = HttpRequest.newBuilder(URI.create(serviceURL + "deleteProduct/0")).DELETE().build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(request,
				HttpResponse.BodyHandlers.ofString());
		if (response.get().statusCode() == 500)
			System.out.println("Product Not Available to delete");
		else {
			Product bean = JSONUtils.convertFromJsonToObject(response.get().body(), Product.class);
			System.out.println(bean);
		}
		response.join();
	}

	// send request to update the product details.
	public static void updateProduct() throws InterruptedException, ExecutionException, IOException {
		Product bean = new Product();
		bean.setId(1);
		bean.setName("Hand Wash");
		bean.setDescription("Herbal Prodcuct by XYZ company");
		bean.setPrice(198.10);
		String inputJson = JSONUtils.convertFromObjectToJson(bean);
		HttpRequest request = HttpRequest.newBuilder(URI.create(serviceURL + "updateProduct"))
				.header("Content-Type", "application/json").PUT(HttpRequest.BodyPublishers.ofString(inputJson)).build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(request,
				HttpResponse.BodyHandlers.ofString());
		if (response.get().statusCode() == 500)
			System.out.println("Product Not Avaialble to update");
		else {
			bean = JSONUtils.convertFromJsonToObject(response.get().body(), Product.class);
			System.out.println(bean);
		}
		response.join();
	}

	// sending request retrieve the product based on the productId
	public static void getProductDetailsById() throws InterruptedException, ExecutionException, IOException {
		HttpRequest req = HttpRequest.newBuilder(URI.create(serviceURL + "getDetailsById/1")).GET().build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(req, BodyHandlers.ofString());
		response.thenAccept(res -> System.out.println(res));
		if (response.get().statusCode() == 500)
			System.out.println("Product Not Avaialble");
		else {
			Product bean = JSONUtils.convertFromJsonToObject(response.get().body(), Product.class);
			System.out.println(bean);
		}
		response.join();
	}

	// send request to REST API to Add new product
	public static void addProduct() throws JsonProcessingException, InterruptedException, ExecutionException {
		Product product = new Product(3, "Soap", "Gel Soap", 60.50);
		String inputJson = JSONUtils.convertFromObjectToJson(product);

		HttpRequest request = HttpRequest.newBuilder(URI.create(serviceURL + "addProduct"))
				.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(inputJson))
				.build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(request,
				HttpResponse.BodyHandlers.ofString());
		System.out.println(response.get().body());

	}

	// sending request to REST API to retrieve all the products
	public static void getAllProducts()
			throws JsonMappingException, JsonProcessingException, InterruptedException, ExecutionException {
		System.out.println("In getAll Products");
		HttpRequest request = HttpRequest.newBuilder(URI.create(serviceURL + "getDetails")).GET().build();
		CompletableFuture<HttpResponse<String>> response = client.sendAsync(request, BodyHandlers.ofString());
		System.out.println();
		response.thenAccept(res -> System.out.println(res));

		List<Product> products = JSONUtils.convertFromJsonToList(response.get().body(),
				new TypeReference<List<Product>>() {
				});

		products.forEach(System.out::println);
		response.join();
	}

}
