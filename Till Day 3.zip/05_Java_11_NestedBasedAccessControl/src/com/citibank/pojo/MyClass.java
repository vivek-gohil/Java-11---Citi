package com.citibank.pojo;

public class MyClass {
	private String name = "Citibank NA";

	public class NewClass {
		public void printName() {
			System.out.println(name);
		}
	}
}
