package com.citibank.main;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

public class MemoryLeakDemo {

	private static BlockingQueue<byte[]> queue = new LinkedBlockingDeque<byte[]>();

	public static void main(String[] args) {

		Runnable producer = () -> {
			while (true) {
				// generates 1 mb of object every 10ms
				queue.offer(new byte[1 * 1024 * 1024]);
				try {
					TimeUnit.MILLISECONDS.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		};

		Runnable consumer = () -> {
			while (true) {
				// process every 100ms
				try {
					queue.take();
					TimeUnit.MILLISECONDS.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		new Thread(producer, "Producer Thread").start();
		new Thread(consumer, "Consumer Thread").start();
	}
}
