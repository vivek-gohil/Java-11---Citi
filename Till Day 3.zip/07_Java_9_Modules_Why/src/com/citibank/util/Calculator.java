package com.citibank.util;

import com.citibank.util.internal.CalculatorHelper;

public class Calculator {

	CalculatorHelper helper = new CalculatorHelper();

	public int add(int i, int j) {
		return helper.add(i, j);
	}

	public int add(double i, double j) {
		return helper.add((int) i, (int) j);
	}
}
