package com.citibank.main;

public class MyThreadMain {
	public static void main(String[] args) {
		// 1. Using Class implementation
		ThreadOne one = new ThreadOne();
		Thread thread = new Thread(one);
		thread.start();

		// 2 . Using anonymous inner class
		Thread threadTwo = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("We are in ThreadTwo");
			}
		});
		threadTwo.start();

		// 3 . Using Lambda Expression
		Thread threadThree = new Thread(() -> System.out.println("We are in ThreadThree"));
		threadThree.start();
	}
}

class ThreadOne implements Runnable {
	@Override
	public void run() {
		System.out.println("We are in ThreadOne");
	}
}
