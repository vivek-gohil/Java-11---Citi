package com.citibank.main;

public class GoodAfternoonGreeting implements Greeting {
	@Override
	public void perfom() {
		System.out.println("Good Afternoon!!");
	}
}
