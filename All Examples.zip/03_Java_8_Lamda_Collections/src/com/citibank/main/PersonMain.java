package com.citibank.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.citibank.pojo.Person;

public class PersonMain {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharekar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		// Code without lambda exprssion
		// 1 :: Sort the list by last name
		Collections.sort(people, new Comparator<Person>() {
			@Override
			public int compare(Person p1, Person p2) {
				return p1.getLastName().compareTo(p2.getLastName());
			}
		});
		// 2 :: Create a method that print all the elements in the list
		printAll(people);

		System.out.println("-".repeat(50));
		System.out.println("Beginning with G");
		// 3 :: Create a method that prints all the people that have last name beginning
		// with G
		// printLastNameBeginningWithG(people);
		printConditionally(people, new Condition() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().startsWith("G"))
					return true;
				return false;
			}
		});

		System.out.println("-".repeat(50));
		System.out.println("Ending with L");
		// 4 :: Create a method that prints all the people that have last name ending
		// with L
		// printLastNameEndingWithL(people);
		printConditionally(people, new Condition() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().endsWith("l"))
					return true;
				return false;
			}
		});

	}

//	private static void printLastNameEndingWithL(List<Person> people) {
//		for (Person person : people) {
//			if (person.getLastName().endsWith("l")) {
//				System.out.println(person);
//			}
//		}
//	}
//
//	private static void printLastNameBeginningWithG(List<Person> people) {
//		for (Person person : people) {
//			if (person.getLastName().startsWith("G")) {
//				System.out.println(person);
//			}
//		}
//	}

	public static void printConditionally(List<Person> people, Condition condition) {
		for (Person person : people) {
			if (condition.test(person)) {
				System.out.println(person);
			}
		}
	}

	private static void printAll(List<Person> people) {
		for (Person person : people) {
			System.out.println(person);
		}
	}
}

interface Condition {
	boolean test(Person person);
}
