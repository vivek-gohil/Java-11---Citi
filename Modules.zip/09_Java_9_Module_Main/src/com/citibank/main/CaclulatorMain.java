package com.citibank.main;

import com.citibank.util.Calculator;

public class CaclulatorMain {

	public static void main(String[] args) {
		System.out.println("Hello");

		Calculator calculator = new Calculator();
		int result = calculator.add(4, 5);
		System.out.println("Result is :: " + result);

		System.out.println("-".repeat(50));
		result = calculator.add(5.7, 9.4);
		System.out.println("Result is :: " + result);

	}

}
