package com.citibank.main;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;
import java.util.function.IntBinaryOperator;

public class StreamReduceMain {

	public static void main(String[] args) {
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		// Sum of all numbers

		int sum = 0;
		for (int i : numbers) {
			sum += i;
		}
		System.out.println(sum);

		System.out.println("-".repeat(50));

		System.out.println("Sum ::" + Arrays.stream(numbers).reduce(new IntBinaryOperator() {

			@Override
			public int applyAsInt(int left, int right) {
				System.out.println("Left :: " + left + "Right :: " + right);
				return left + right;
			}
		}));

		OptionalInt sumOptional = Arrays.stream(numbers).reduce((a, b) -> a + b);
		
		System.out.println(sumOptional.getAsInt());

	}

}
