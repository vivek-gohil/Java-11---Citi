package com.citibank.main;

public class MethodReferenceMain {

	public static void main(String[] args) {
		Thread mainThread = Thread.currentThread();

		if (mainThread.isDaemon()) {
			System.out.println("Main is daemon thread");
		} else {
			System.out.println("Main is not daemon thread");
		}

		Thread thread = new Thread(new Runnable() {
			public void run() {
				System.out.println("in the thread");
			}
		});

		thread.start();
		System.out.println("-".repeat(50));
		Thread thread2 = new Thread(() -> printMessage());
		thread2.start();

		System.out.println("-".repeat(50));

		Thread thread3 = new Thread(MethodReferenceMain::printMessage); // same as () -> printMessage();
		thread3.start();

	}

	public static void printMessage() {
		System.out.println("Hello from printMessage()");
	}

}
