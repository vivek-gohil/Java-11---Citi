package com.citibank.main;

public class Greeter {
	public void greet(Greeting greeting) {
		greeting.perfom();
	}

	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		// greeter.greet();

		// GoodMorningGreeting greeting = new GoodMorningGreeting();
		GoodAfternoonGreeting greeting = new GoodAfternoonGreeting();

		// Greeting greeting = new GoodAfternoonGreeting();
		// Greeting greeting = new GoodMorningGreeting();

		Greeting goodEveningGreeting = new Greeting() {
			@Override
			public void perfom() {
				System.out.println("Good Evening!!");
			}
		};
		
		Greeting goodNightGreeting = () -> System.out.println("Good Night!!");
		
		greeter.greet(goodNightGreeting);
		
	}
}
