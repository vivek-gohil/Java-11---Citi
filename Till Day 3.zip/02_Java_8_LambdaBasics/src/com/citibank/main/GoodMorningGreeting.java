package com.citibank.main;

public class GoodMorningGreeting implements Greeting {
	@Override
	public void performGreeting() {
		System.out.println("Good Morning");
	}
}
