package com.citibank.main;

public class Greeter {

	public void greet(Greeting greeting) {
		greeting.performGreeting();
	}

	public static void main(String[] args) {
		Greeter greeter = new Greeter();

		// GoodMorningGreeting goodMorningGreeting = new GoodMorningGreeting();
		GoodAfternoonGreeting afternoonGreeting = new GoodAfternoonGreeting();

		// anonymous inner class implementation
		Greeting goodEveningGreeting = new Greeting() {
			public void performGreeting() {
				System.out.println("Good Evening");
			}
		};

		// Functional Interface
		Greeting goodNightGreeting = () -> System.out.println("Good Night");

//		class asdfas44 implements Greeting {
//			public void performGreeting() {
//				System.out.println("Good Evening");
//			}
//		}

		greeter.greet(() -> System.out.println("Good Night"));
	}

}
