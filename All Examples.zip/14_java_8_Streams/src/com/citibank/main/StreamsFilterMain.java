package com.citibank.main;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamsFilterMain {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Vivek", "Bahubali", "Trupti", "Samarth");

		// Print all accept Bahubali
		for (String name : names) {
			if (!name.equals("Bahubali")) {
				System.out.println(name);
			}
		}
		System.out.println("-".repeat(50));
		names.stream().filter(name -> !name.equals("Bahubali")).forEach(System.out::println);

		System.out.println("-".repeat(50));
		names.stream().filter(StreamsFilterMain::isNotBahubali).forEach(System.out::println);

		System.out.println("-".repeat(50));
		names.forEach(System.out::println);

		System.out.println("-".repeat(50));
		names = names.stream().filter(StreamsFilterMain::isNotBahubali).collect(Collectors.toList());

		System.out.println("-".repeat(50));
		names.forEach(System.out::println);

	}

	private static boolean isNotBahubali(String name) {
		return !name.equals("Bahubali");
	}

}
