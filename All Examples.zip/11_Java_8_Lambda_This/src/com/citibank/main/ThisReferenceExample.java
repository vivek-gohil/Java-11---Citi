package com.citibank.main;

public class ThisReferenceExample {

	public void doProcess(int i, Process p) {
		p.process(i);
	}

	// lets create a new non static method
	public void execute() {
		doProcess(10, i -> {
			System.out.println("Value of i = " + i);
			System.out.println(this);
		});
	}

	public static void main(String[] args) {
		ThisReferenceExample example = new ThisReferenceExample();

//		example.doProcess(10, new Process() {
//			@Override
//			public void process(int i) {
//				System.out.println("Value of i = " + i);
//				System.out.println(this);
//			}
//
//			public String toString() {
//				return "toString method of anonymous inner class";
//			}
//		});

		example.execute();

	}

	@Override
	public String toString() {
		return "toString method of ThisReferenceExample";
	}

}

interface Process {
	void process(int i);
}
