package com.citibank.main;

import com.citibank.util.Calculator;
import com.citibank.util.internal.CalculatorHelper;

public class CalculationMain {
	
	//Client Side
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		int result = calculator.add(4, 5);
		System.out.println("Result is :: " + result);
		System.out.println("-".repeat(50));
		result = calculator.add(3.5, 9.2);
		System.out.println("Result is :: " + result);
		
		CalculatorHelper calculatorHelper = new CalculatorHelper();
		calculatorHelper.add(1, 2);
	}
}
