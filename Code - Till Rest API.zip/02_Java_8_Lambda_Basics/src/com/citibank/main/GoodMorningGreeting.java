package com.citibank.main;

public class GoodMorningGreeting implements Greeting {
	@Override
	public void perfom() {
		System.out.println("Good Morning!!");
	}
}
