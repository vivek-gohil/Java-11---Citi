package com.citibank.main;

public class LambdaVsAnonymousClassMain {

	public void doProcess(int i, Process p) {
		System.out.println("In do process");
		p.process(i);
		System.out.println("do process completed");
	}

	public void execute() {
		doProcess(10, i -> {
			System.out.println("Value of i = " + i);
			System.out.println(this);
		});
	}

	public static void main(String[] args) {
		LambdaVsAnonymousClassMain classMain = new LambdaVsAnonymousClassMain();

		// MyProcess myProcess = new MyProcess();
		// classMain.doProcess(10, myProcess);

//		classMain.doProcess(10, new Process() {
//
//			@Override
//			public void process(int i) {
//				System.out.println("Value of i = " + i);
//				System.out.println(this);
//			}
//
//			@Override
//			public String toString() {
//				return "toString of inner class";
//			}
//		});

		classMain.execute();

	}

	public String toString() {// TODO Auto-generated method stub
		return "toString of LambdaVsAnonymousClassMain";
	}
}

class MyProcess implements Process {
	@Override
	public void process(int i) {
		System.out.println(i);
	}
}

interface Process {
	void process(int i);
}
